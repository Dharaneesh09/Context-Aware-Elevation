package com.smartelevation;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.LinkedHashMap;
import java.util.Scanner;
import java.util.Vector;
//
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

class Person{
    String name;
    long houseID;
    long carID;
    long floor;
    JSONObject ConfigProf;
}

class Camera{
    int state;
    String resItems;
    static int cloudID;
    int floor;

    Camera(int flo){
        floor = flo;
        state = 1;
    }
}

public class ElevatorBody
{
    static int state;
    static Vector<Integer> vibState; // 100
    static Vector<Integer> vibration;

    static int wtSenID;  // 101
    static int wtSenState;
    static int extWeight;
    static int sysWt = 100; //kg
    static int wtThresh = 1100; //kg

    static Vector<Integer> motorID; // 102
    static Vector<Integer> motorState;
    static int motorDirection;

    // static Vector<Integer> extinguisherID; // 103
    static Vector<Integer> extinguisherState; // 103

    static long presentLocation = 0;
    static long nextLocation = 0;
    static long selectedLocation = 0;

    static Vector<Integer> tempState; // 104
    static Vector<Integer> temperature;

    static int airConditionerID;  // 105
    static int airConditionerSetTemp;

    static long floorSensorID; // 106
    static int FCount = 0;

    static Alarm alarm;

    static Vector<Camera> cam; // 888

    static Maintenance M;
    static LinkedHashMap<String,Person> per = new LinkedHashMap<>(); //999
    static JSONParser jsonParser = new JSONParser();

    static NetworkAdaptor net = new NetworkAdaptor();

    static Scanner SysConsole = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Elevator Powered ON...");
        //ContextProcessor MyCP = new ContextProcessor();
        state = 1;
        alarm = new Alarm();

        M = new Maintenance();

        // 5 vibration sensors for 5 floors
        vibState = new Vector<>();vibration = new Vector<>();
        vibState.add(1);vibration.add(0);
        vibState.add(1);vibration.add(0);
        vibState.add(1);vibration.add(0);
        vibState.add(1);vibration.add(0);
        vibState.add(1);vibration.add(0);

        // 5 extinguishers sensors for 5 floors
        extinguisherState = new Vector<>();
        extinguisherState.add(0);
        extinguisherState.add(0);
        extinguisherState.add(0);
        extinguisherState.add(0);
        extinguisherState.add(0);


        // Let's say there are 6 cameras for 5 floors and 1 inside cabin
        cam = new Vector<>();
        cam.add(new Camera(0));
        cam.add(new Camera(1));
        cam.add(new Camera(2));
        cam.add(new Camera(3));
        cam.add(new Camera(4));
        cam.add(new Camera(100)); // inside cabin

        //Let's say there are 6 temperature sensors for 5 floors and 1 inside cabin
        tempState = new Vector<>();temperature = new Vector<>();
        tempState.add(1);temperature.add(29);
        tempState.add(1);temperature.add(29);
        tempState.add(1);temperature.add(29);
        tempState.add(1);temperature.add(29);
        tempState.add(1);temperature.add(29);
        tempState.add(1);temperature.add(29); // inside cabin


        // must be in while loop
        executeData("data/context.json");

    }

    private static void executeData(String s){
        if(state == 1) {
            try (FileReader reader = new FileReader(s)) {
                //Delete context file
                //Read JSON file
                Object obj = jsonParser.parse(reader);

                JSONArray contextList = (JSONArray) obj;
                //System.out.println(contextList);

                contextList.forEach(i -> doReqOperation((JSONObject) i));


            } catch (FileNotFoundException e) {
                e.printStackTrace();

            } catch (IOException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        else{
            System.out.println("Ignoring Context, Elevator Powered Off...");
        }
    }

    private static void doReqOperation(JSONObject a){
        long ID = (long) a.get("ID");
        //System.out.println(ID);
        int ind = (int)ID/1000;
        int device = (int)ID % 1000;

        //System.out.println(device);
        switch (device){
            case 000:
                System.out.println("\nAlarm Pressed");
                alarm.toggle();
                break;
            case 100:
                System.out.println("\nThis is from Vibration Sensor");
                long freq = (long) a.get("Freq");
                System.out.println("Ind : "+ind);
                System.out.println("Abnormal Vibrations detected at floor "+ind);
                vibState.set(ind, 1);
                vibration.set(ind, (int) freq);
                System.out.println("Calling Maintenance Team");
                net.send("Abnormal Vibrations detected at floor "+ind);
                M.call("Abnormal vibrations in floor "+ind);
                break;
            case 101:
                System.out.println("\nThis is from weight Sensor");
                long extWt = (long) a.get("Wt") - sysWt;
                System.out.println("External Weight : " + extWt);
                if (extWt < wtThresh) {
                    extWeight = (int) extWt;

                    if (alarm.status == 1) {
                        alarm.down();
                    }
                } else {
                    System.out.println("Too Heavy, Raising alarms");
                    alarm.raise(0);
                }
                break;
            case 102:
                System.out.println("\nThis is from Motor");
                break;
            case 103:
                System.out.println("\nThis is from Extinguisher");
                break;
            case 104:
                System.out.println("\nThis is from Temp Sensor");
                long temp = (long) a.get("Temp");
                temperature.set(ind, (int) temp);
                if(temp > 75){
                    if(ind != 99)
                    System.out.println("High temperature Detected in floor "+ind);
                    else System.out.println("High temperature Detected inside the cabin");

                    System.out.println("Activating extinguishers");
                    extinguisherState.set(ind, 1);
                    state = 0;
                    System.out.println("Power OFF elevator");
                }
                break;
            case 105:
                System.out.println("\nThis is from Air Conditioner");
                break;
            case 106:
                if(ind == presentLocation){
                    FCount ++;
                    //System.out.println(FCount);
                    if(FCount > 4){
                        System.out.println("Uncertainty detected!!!, May be faulty floor Sensor");
                        net.send("Abnormal Behavior by floor Sensor "+ind);
                        M.call("Abnormal Behavior by floor Sensor "+ind);
                    }
                }
                else {
                    FCount = 0;
                    System.out.println("\nThis is from Floor Sensor");
                    presentLocation = ind;
                    System.out.println("The cabin is in floor : " + ind);
                    floorSensorID = ID;
                }
                break;
            case 888:
                if (ind == 100) {
                    ind = 5;
                    Camera c = cam.get(5);
                    System.out.println("\nThis is from Internal Camera");
                    String info = (String) a.get("info");
                    //System.out.println(info);
                    if (info.equals("person")) {
                        // if the person is unknown, it will ask the details and save them
                        if (a.get("person").equals("unknown")) {
                            System.out.println("Do you live here??");
                            if (SysConsole.next().equals("yes")) {
                                Person P = new Person();
                                System.out.println("Enter your Name : ");
                                P.name = SysConsole.nextLine();
                                System.out.println("Enter your Floor no : ");
                                P.floor = SysConsole.nextLong();
                                System.out.println("Enter your House ID : ");
                                P.houseID = SysConsole.nextLong();
                                System.out.println("Enter your Car ID : ");
                                P.carID = SysConsole.nextLong();
                                System.out.println("Uploading to cloud, Your details will be asked for confirmation");
                                per.put(P.name, P);
                            }
                            else{
                                selectedLocation = SysConsole.nextLong();
                                System.out.println("Moving to floor : " + selectedLocation);
                                nextLocation = selectedLocation;
                            }
                        }
                        Person p2 = per.get((String) a.get("person"));
                        System.out.println("Detected person " + p2.name+" at location "+presentLocation);
                        if (p2.floor != presentLocation) {
                            System.out.println("Moving to floor : " + p2.floor);
                            nextLocation = p2.floor;
                            //motorDirection = (nextLocation-presentLocation > 0 ) ? 1: (nextLocation-presentLocation == 0 ) ? 0 : -1;
                        } else {
                            System.out.println("Asking to select a floor...");
                            selectedLocation = SysConsole.nextLong();
                            System.out.println("Moving to floor : " + selectedLocation);
                            nextLocation = selectedLocation;
                        }
                    }
                    else if (info.equals("alert")) {
                        System.out.println("Unfavourable Situation detected, Raising alarms");
                        c.resItems = (String) a.get("ResItem");
                        net.send(c.resItems + " Detected by camera " + ind);
                        alarm.raise(1);
                    }
                }
                else{
                    System.out.println("\nThis is from External Camera");
                    System.out.println("Moving to floor : " + ind);
                    nextLocation = ind;
                }
                break;
            case 999:
                Person p = new Person();
                p.name = (String)a.get("name");
                System.out.println("\nThis is a "+p.name+"'s profile update");
                p.carID = (long) a.get("carID");
                p.houseID = (long) a.get("houseID");
                p.ConfigProf = (JSONObject) a.get("Config");
                p.floor = (long) a.get("floor");
                per.put(p.name, p);
                break;
            default:
                System.out.println("\nUnable to Recognize the device...");
        }
    }
}

//class ContextProcessor{
//    int extWt; // ExternalWt integer;
//    Vector<Integer> emerCode;
//    int cloudID = 91238472;
//    String netString;
//    boolean struStatus;
//    int selLoc;
//    int liftLocation;
//    Vector<Person> p;
//    int CabTemp;
//
//}

class Maintenance{
    String Prob;
    int status = 0;

    void call(String s){
        System.out.println("Received Maintenance call for "+s);
        Prob = s;
        status = 1;
    }

}

class NetworkAdaptor{
    Vector<Integer> portNo;
    String info;

    public void send(String s){
        info = s;
        System.out.println("Transmitting info :"+ s);
    }

}
class Alarm{
    int status;
    int emerCode; // 0 - heavy Weight, 1 - unfavourable situation from camera

    public void raise(int i){
        status = 1;
        emerCode = i;
        System.out.println("!!! Alarms Raised !!!");
    }

    public void down(){
        status = 0;
        System.out.println("...Alarms Down...");
    }

    public void toggle(){
        if(status == 0){
            System.out.println("!!! Alarms Raised !!!");
            status = 1;
            return;
        }
        status = 0;
        System.out.println("...Alarms Down...");
    }
}

